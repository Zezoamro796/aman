require('dotenv').config();
const mongoose = require('mongoose');
const Test = require('./models/Test');

async function seedTestData() {
  try {
    // الاتصال بقاعدة البيانات
    await mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    
    console.log('✅ Connected to MongoDB');

    // التحقق من وجود تحاليل بالفعل
    const existingTests = await Test.countDocuments();
    if (existingTests > 0) {
      console.log(`⚠️ ${existingTests} tests already exist, skipping seed`);
      process.exit(0);
    }

    // بيانات التحاليل التجريبية
    const testData = [
      {
        name: 'تحليل دم شامل',
        description: 'تحليل شامل لجميع مكونات الدم',
        price: 150,
        waitingTime: 1,
        category: 'دم',
        preparation: 'صيام 8-12 ساعة',
        normalRange: '4.5-5.5 مليون/ميكرولتر',
        unit: 'مليون/ميكرولتر'
      },
      {
        name: 'تحليل سكر الدم',
        description: 'قياس مستوى السكر في الدم',
        price: 50,
        waitingTime: 1,
        category: 'دم',
        preparation: 'صيام 8 ساعات',
        normalRange: '70-100 ملجم/ديسيلتر',
        unit: 'ملجم/ديسيلتر'
      },
      {
        name: 'تحليل فيتامين د',
        description: 'قياس مستوى فيتامين د في الدم',
        price: 200,
        waitingTime: 2,
        category: 'دم',
        preparation: 'لا يحتاج صيام',
        normalRange: '30-100 نانوغرام/مل',
        unit: 'نانوغرام/مل'
      },
      {
        name: 'تحليل حمل',
        description: 'اختبار الحمل في الدم',
        price: 80,
        waitingTime: 1,
        category: 'دم',
        preparation: 'لا يحتاج صيام',
        normalRange: 'أقل من 5 ميكرو وحدة/مل',
        unit: 'ميكرو وحدة/مل'
      },
      {
        name: 'تحليل وظائف الكبد',
        description: 'قياس إنزيمات الكبد',
        price: 120,
        waitingTime: 1,
        category: 'دم',
        preparation: 'صيام 8 ساعات',
        normalRange: '7-56 وحدة/لتر',
        unit: 'وحدة/لتر'
      },
      {
        name: 'تحليل وظائف الكلى',
        description: 'قياس وظائف الكلى',
        price: 100,
        waitingTime: 1,
        category: 'دم',
        preparation: 'صيام 8 ساعات',
        normalRange: '0.7-1.3 ملجم/ديسيلتر',
        unit: 'ملجم/ديسيلتر'
      },
      {
        name: 'تحليل البول',
        description: 'فحص شامل للبول',
        price: 60,
        waitingTime: 1,
        category: 'بول',
        preparation: 'عينة بول صباحية',
        normalRange: 'pH 4.5-8.0',
        unit: 'pH'
      },
      {
        name: 'تحليل البراز',
        description: 'فحص البراز للطفيليات',
        price: 70,
        waitingTime: 2,
        category: 'براز',
        preparation: 'عينة براز طازجة',
        normalRange: 'سلبي',
        unit: 'سلبي/إيجابي'
      }
    ];

    // إضافة البيانات
    await Test.insertMany(testData);

    console.log(`✅ Successfully seeded ${testData.length} tests`);
    console.log('📋 Available tests:');
    testData.forEach(test => {
      console.log(`   - ${test.name}: ${test.price} ج.م`);
    });

    process.exit(0);

  } catch (error) {
    console.error('❌ Error seeding test data:', error);
    process.exit(1);
  }
}

seedTestData(); 