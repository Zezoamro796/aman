const mongoose = require('mongoose');

const testResultSchema = new mongoose.Schema({
  appointmentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Appointment',
    required: true
  },
  patientId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  type: {
    type: String,
    required: true,
    trim: true
  },
  resultDate: {
    type: Date,
    default: Date.now
  },
  fileUrl: {
    type: String,
    required: true
  },
  fileName: {
    type: String,
    required: true
  },
  fileSize: {
    type: Number
  },
  status: {
    type: String,
    enum: ['جاهز', 'قيد المعالجة', 'مرفوض'],
    default: 'جاهز'
  },
  notes: {
    type: String,
    trim: true
  },
  uploadedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, {
  timestamps: true
});

// إنشاء فهارس للبحث السريع
testResultSchema.index({ patientId: 1, resultDate: -1 });
testResultSchema.index({ appointmentId: 1 });
testResultSchema.index({ status: 1 });

module.exports = mongoose.model('TestResult', testResultSchema); 