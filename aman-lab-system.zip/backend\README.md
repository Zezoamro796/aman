# معمل أمان للتحاليل الطبية - Backend

## 📋 المتطلبات

- Node.js (الإصدار 14 أو أحدث)
- MongoDB Atlas (أو MongoDB محلي)
- npm أو yarn

## 🚀 التثبيت والتشغيل

### 1. تثبيت الـ Dependencies
```bash
npm install
```

### 2. إعداد ملف البيئة (.env)
قم بتعديل ملف `.env` وأضف معلومات قاعدة البيانات الخاصة بك:

```env
MONGO_URI=mongodb+srv://your_username:your_password@your_cluster.mongodb.net/lab_management?retryWrites=true&w=majority
PORT=3000
JWT_SECRET=your_super_secret_jwt_key_here_make_it_long_and_random
```

### 3. إنشاء مستخدم مدير
```bash
node createAdmin.js
```

### 4. إضافة بيانات تجريبية (اختياري)
```bash
node seedData.js
```

### 5. تشغيل السيرفر
```bash
# للتشغيل العادي
npm start

# للتطوير (مع إعادة التشغيل التلقائي)
npm run dev
```

## 📡 API Endpoints

### المصادقة (Authentication)
- `POST /api/register` - تسجيل مستخدم جديد
- `POST /api/login` - تسجيل الدخول
- `GET /api/profile` - معلومات المستخدم

### المواعيد (Appointments)
- `POST /api/appointments` - إنشاء موعد جديد
- `GET /api/appointments` - جلب المواعيد
- `PATCH /api/appointments/:id/status` - تحديث حالة الموعد
- `DELETE /api/appointments/:id` - حذف موعد
- `GET /api/appointments/stats` - إحصائيات المواعيد

### التحاليل (Tests)
- `GET /api/tests` - جلب التحاليل المتاحة
- `POST /api/tests` - إضافة تحليل جديد
- `PUT /api/tests/:id` - تحديث تحليل
- `DELETE /api/tests/:id` - حذف تحليل

### نتائج التحاليل (Test Results)
- `POST /api/test-results` - رفع نتيجة تحليل
- `GET /api/test-results` - جلب نتائج التحاليل
- `DELETE /api/test-results/:id` - حذف نتيجة تحليل

### الاستشارات (Consultations)
- `POST /api/consultations` - إنشاء استشارة جديدة
- `GET /api/consultations` - جلب الاستشارات
- `POST /api/consultations/:id/reply` - الرد على استشارة
- `PATCH /api/consultations/:id/status` - تحديث حالة الاستشارة
- `DELETE /api/consultations/:id` - حذف استشارة
- `GET /api/consultations/stats` - إحصائيات الاستشارات

### الصحة (Health)
- `GET /api/health` - التحقق من حالة السيرفر

## 🔐 الأمان

- جميع الـ endpoints (ما عدا التسجيل وتسجيل الدخول) تتطلب JWT token
- كلمات المرور مشفرة باستخدام bcrypt
- التحقق من الصلاحيات للمديرين

## 📊 قاعدة البيانات

### النماذج (Models)
- **User**: المستخدمين (مرضى ومديرين)
- **Appointment**: المواعيد
- **Test**: التحاليل المتاحة
- **TestResult**: نتائج التحاليل
- **Consultation**: الاستشارات الطبية

## 👤 المستخدم الافتراضي

بعد تشغيل `createAdmin.js`، يمكنك تسجيل الدخول كمدير باستخدام:
- **البريد الإلكتروني**: admin@amanlab.com
- **رقم الهاتف**: 0123456789
- **كلمة المرور**: admin123

⚠️ **تحذير**: قم بتغيير كلمة المرور بعد أول تسجيل دخول!

## 🛠️ التطوير

### تشغيل في وضع التطوير
```bash
npm run dev
```

### إعادة تشغيل السيرفر
```bash
# في وضع التطوير، السيرفر يعيد التشغيل تلقائياً عند تغيير الملفات
# أو يمكنك إيقافه بـ Ctrl+C وإعادة تشغيله
```

## 📝 ملاحظات مهمة

1. تأكد من أن MongoDB Atlas متصل بالإنترنت
2. تأكد من أن IP address مسموح به في MongoDB Atlas
3. تأكد من صحة بيانات الاتصال في ملف `.env`
4. في الإنتاج، استخدم JWT_SECRET قوي وآمن

## 🐛 استكشاف الأخطاء

### مشاكل الاتصال بقاعدة البيانات
- تحقق من صحة MONGO_URI
- تحقق من إعدادات Network Access في MongoDB Atlas
- تحقق من صحة اسم المستخدم وكلمة المرور

### مشاكل الـ CORS
- تأكد من أن Frontend يعمل على المنفذ الصحيح
- تحقق من إعدادات CORS في server.js

### مشاكل الـ JWT
- تأكد من وجود JWT_SECRET في ملف .env
- تأكد من إرسال Token في header Authorization 