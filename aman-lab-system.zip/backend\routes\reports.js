const express = require('express');
const router = express.Router();
const Appointment = require('../models/Appointment');
const Test = require('../models/Test');
const TestResult = require('../models/TestResult');

// Monthly report: appointments and revenue per week for current month
router.get('/reports/monthly', async (req, res) => {
  try {
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth();
    const start = new Date(year, month, 1);
    const end = new Date(year, month + 1, 1);
    // Group by week number in month
    const data = await Appointment.aggregate([
      { $match: { date: { $gte: start, $lt: end } } },
      { $addFields: {
          week: { $ceil: { $divide: [ { $dayOfMonth: "$date" }, 7 ] } }
        }
      },
      { $group: {
          _id: "$week",
          appointments: { $sum: 1 },
          // revenue: count * 0 (no price in appointment, can be improved if price is available)
        }
      },
      { $sort: { _id: 1 } }
    ]);
    // Optionally, fetch revenue from TestResult if price is needed
    res.json(data.map(w => ({ week: `الأسبوع ${w._id}`, appointments: w.appointments })));
  } catch (err) {
    res.status(500).json({ message: 'خطأ في التقرير الشهري', error: err.message });
  }
});

// Daily report: appointments per time slot for today
router.get('/reports/daily', async (req, res) => {
  try {
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const end = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
    const slots = ['8-10', '10-12', '12-2', '2-4', '4-6'];
    const slotRanges = [
      { start: '08:00', end: '10:00' },
      { start: '10:00', end: '12:00' },
      { start: '12:00', end: '14:00' },
      { start: '14:00', end: '16:00' },
      { start: '16:00', end: '18:00' }
    ];
    const appointments = await Appointment.find({ date: { $gte: start, $lt: end } });
    const slotCounts = slots.map((slot, i) => {
      const count = appointments.filter(app => {
        const t = app.time ? app.time.replace(/[\u0627-\u064A\s]/g, '') : '';
        return t >= slotRanges[i].start && t < slotRanges[i].end;
      }).length;
      return { slot, appointments: count };
    });
    res.json(slotCounts);
  } catch (err) {
    res.status(500).json({ message: 'خطأ في التقرير اليومي', error: err.message });
  }
});

// Most requested tests (top 5)
router.get('/reports/tests', async (req, res) => {
  try {
    const data = await Appointment.aggregate([
      { $group: { _id: "$type", count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 5 }
    ]);
    res.json(data.map(t => ({ test: t._id, count: t.count })));
  } catch (err) {
    res.status(500).json({ message: 'خطأ في تقرير التحاليل', error: err.message });
  }
});

module.exports = router; 