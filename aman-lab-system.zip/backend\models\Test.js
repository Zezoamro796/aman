const mongoose = require('mongoose');

const testSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
    unique: true
  },
  description: {
    type: String,
    trim: true
  },
  price: {
    type: Number,
    required: true,
    min: 0
  },
  waitingTime: {
    type: Number,
    required: true,
    min: 1,
    default: 1
  },
  available: {
    type: Boolean,
    default: true
  },
  category: {
    type: String,
    enum: ['دم', 'بول', 'براز', 'أخرى'],
    default: 'أخرى'
  },
  preparation: {
    type: String,
    trim: true
  },
  normalRange: {
    type: String,
    trim: true
  },
  unit: {
    type: String,
    trim: true
  },
  requirements: { type: String, trim: true }, // متطلبات التحليل
  createdAt: { type: Date, default: Date.now }
}, {
  timestamps: true
});

// إنشاء فهارس للبحث السريع
testSchema.index({ name: 1 });
testSchema.index({ category: 1 });
testSchema.index({ available: 1 });

module.exports = mongoose.model('Test', testSchema); 