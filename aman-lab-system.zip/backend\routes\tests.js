const express = require('express');
const router = express.Router();
const Test = require('../models/Test');
const TestResult = require('../models/TestResult');
const Appointment = require('../models/Appointment');
const User = require('../models/User');
const jwt = require('jsonwebtoken');

// Middleware للتحقق من الـ token
const authenticateToken = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
      return res.status(401).json({ message: 'Token مطلوب' });
    }
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback_secret');
    const user = await User.findById(decoded.userId);
    if (!user) {
      return res.status(404).json({ message: 'المستخدم غير موجود' });
    }
    req.user = user;
    next();
  } catch (error) {
    res.status(401).json({ message: 'Token غير صالح' });
  }
};

// جلب كل التحاليل
router.get('/tests', authenticateToken, async (req, res) => {
  try {
    const tests = await Test.find();
    res.json(tests);
  } catch (error) {
    res.status(500).json({ message: 'حدث خطأ أثناء جلب التحاليل' });
  }
});

// جلب تحليل واحد
router.get('/tests/:id', authenticateToken, async (req, res) => {
  try {
    const test = await Test.findById(req.params.id);
    if (!test) {
      return res.status(404).json({ message: 'التحليل غير موجود' });
    }
    res.json(test);
  } catch (error) {
    res.status(500).json({ message: 'حدث خطأ أثناء جلب التحليل' });
  }
});

// إضافة تحليل جديد
router.post('/tests', authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'غير مصرح لك' });
    }
    const { name, price, waitingTime, available, description, requirements } = req.body;
    if (!name || !price || !waitingTime) {
      return res.status(400).json({ message: 'يرجى ملء الحقول المطلوبة' });
    }
    const test = new Test({ name, price, waitingTime, available, description, requirements });
    await test.save();
    res.status(201).json({ message: 'تم إضافة التحليل بنجاح', test });
  } catch (error) {
    res.status(500).json({ message: 'حدث خطأ أثناء إضافة التحليل' });
  }
});

// تعديل تحليل
router.put('/tests/:id', authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'غير مصرح لك' });
    }
    const { name, price, waitingTime, available, description, requirements } = req.body;
    const test = await Test.findById(req.params.id);
    if (!test) return res.status(404).json({ message: 'التحليل غير موجود' });
    test.name = name || test.name;
    test.price = price || test.price;
    test.waitingTime = waitingTime || test.waitingTime;
    test.available = available !== undefined ? available : test.available;
    test.description = description || test.description;
    test.requirements = requirements || test.requirements;
    await test.save();
    res.json({ message: 'تم تحديث التحليل بنجاح', test });
  } catch (error) {
    res.status(500).json({ message: 'حدث خطأ أثناء تحديث التحليل' });
  }
});

// حذف تحليل (للمدير)
router.delete('/tests/:id', authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'غير مصرح لك بحذف التحاليل' });
    }
    const { id } = req.params;
    const test = await Test.findByIdAndDelete(id);
    if (!test) {
      return res.status(404).json({ message: 'التحليل غير موجود' });
    }
    res.json({ message: 'تم حذف التحليل بنجاح' });
  } catch (error) {
    console.error('Delete test error:', error);
    res.status(500).json({ message: 'حدث خطأ أثناء حذف التحليل' });
  }
});

// رفع نتيجة تحليل
router.post('/test-results', authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'غير مصرح لك برفع نتائج التحاليل' });
    }
    const { appointmentId, fileUrl, fileName, fileSize, notes } = req.body;
    if (!appointmentId || !fileUrl || !fileName) {
      return res.status(400).json({ message: 'يرجى ملء الحقول المطلوبة' });
    }
    const appointment = await Appointment.findById(appointmentId);
    if (!appointment) {
      return res.status(404).json({ message: 'الموعد غير موجود' });
    }
    const existingResult = await TestResult.findOne({ appointmentId });
    if (existingResult) {
      return res.status(400).json({ message: 'تم رفع نتيجة لهذا التحليل مسبقاً' });
    }
    const testResult = new TestResult({
      appointmentId,
      patientId: appointment.patientId,
      fileUrl,
      fileName,
      fileSize,
      notes,
      type: appointment.type,
      resultDate: new Date()
    });
    await testResult.save();
    appointment.status = 'مكتمل';
    await appointment.save();
    res.status(201).json({ message: 'تم رفع نتيجة التحليل بنجاح', testResult });
  } catch (error) {
    console.error('Upload test result error:', error);
    res.status(500).json({ message: 'حدث خطأ أثناء رفع نتيجة التحليل' });
  }
});

// الحصول على نتائج التحاليل للمريض
router.get('/test-results', authenticateToken, async (req, res) => {
  try {
    let filter = {};
    if (req.user.role === 'patient') {
      filter.patientId = req.user._id;
    }
    const results = await TestResult.find(filter).populate('appointmentId').sort({ resultDate: -1 });
    res.json(results);
  } catch (error) {
    console.error('Get test results error:', error);
    res.status(500).json({ message: 'حدث خطأ أثناء جلب نتائج التحاليل' });
  }
});

module.exports = router; 