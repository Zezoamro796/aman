# معمل أمان للتحاليل الطبية

نظام إدارة شامل لمعمل التحاليل الطبية يتضمن إدارة المرضى، المواعيد، التحاليل، المخزون، والاستشارات الطبية.

## المميزات

- **إدارة المرضى:** تسجيل وإدارة بيانات المرضى
- **المواعيد:** حجز وإدارة مواعيد التحاليل
- **التحاليل:** إدارة أنواع التحاليل ونتائجها
- **المخزون:** إدارة المخزون والمعدات
- **التقارير:** تقارير شاملة عن الأداء
- **الاستشارات:** نظام دردشة مباشر بين المرضى والأدمن
- **واجهة مستخدم:** واجهة عربية سهلة الاستخدام

## التقنيات المستخدمة

### Frontend
- HTML5, CSS3, JavaScript
- Socket.IO Client للدردشة المباشرة
- واجهة مستخدم متجاوبة

### Backend
- Node.js
- Express.js
- MongoDB (MongoDB Atlas)
- Socket.IO للدردشة المباشرة
- JWT للمصادقة

## الرفع على الإنترنت

### الطريقة الأولى: Render (موصى بها)

1. **إنشاء حساب على Render:**
   - اذهب إلى [render.com](https://render.com)
   - سجل حساب جديد

2. **رفع المشروع:**
   - اختر "New Web Service"
   - ارفع مجلد المشروع كاملاً
   - Render سيكتشف ملف `render.yaml` تلقائياً

3. **إعدادات التلقائية:**
   - سيتم رفع Backend على: `https://aman-lab-backend.onrender.com`
   - سيتم رفع Frontend على: `https://aman-lab-frontend.onrender.com`

### الطريقة الثانية: رفع منفصل

#### رفع Backend على Render:
1. اذهب إلى [render.com](https://render.com)
2. اختر "New Web Service"
3. ارفع مجلد `backend` فقط
4. اختر Node.js كـ Runtime
5. اكتب `npm start` كـ Start Command
6. أضف متغيرات البيئة:
   - `MONGO_URI`: رابط MongoDB Atlas
   - `JWT_SECRET`: مفتاح التشفير
   - `NODE_ENV`: production

#### رفع Frontend على Netlify:
1. اذهب إلى [netlify.com](https://netlify.com)
2. اسحب مجلد المشروع الرئيسي (index.html)
3. سيتم رفع الموقع فوراً

## تشغيل محلياً

### متطلبات النظام
- Node.js (الإصدار 14 أو أحدث)
- MongoDB (محلي أو Atlas)

### خطوات التشغيل

1. **تثبيت التبعيات:**
   ```bash
   cd backend
   npm install
   ```

2. **إعداد متغيرات البيئة:**
   - أنشئ ملف `.env` في مجلد `backend`
   - أضف المتغيرات التالية:
   ```
   MONGO_URI=mongodb://localhost:27017/aman_lab
   JWT_SECRET=your_secret_key
   PORT=3000
   ```

3. **تشغيل الخادم:**
   ```bash
   npm start
   ```

4. **فتح الموقع:**
   - افتح `index.html` في المتصفح
   - أو استخدم خادم محلي مثل Live Server

## هيكل المشروع

```
aman-lab/
├── index.html              # الواجهة الرئيسية
├── backend/                # خادم Node.js
│   ├── server.js          # الخادم الرئيسي
│   ├── models/            # نماذج قاعدة البيانات
│   ├── routes/            # مسارات API
│   └── package.json       # تبعيات Backend
├── render.yaml            # إعدادات Render
├── .gitignore            # ملفات Git المهملة
└── README.md             # هذا الملف
```

## API Endpoints

### المصادقة
- `POST /api/register` - تسجيل مستخدم جديد
- `POST /api/login` - تسجيل الدخول
- `GET /api/profile` - معلومات المستخدم

### المرضى
- `GET /api/patients` - قائمة المرضى
- `POST /api/patients` - إضافة مريض جديد
- `PUT /api/patients/:id` - تحديث بيانات مريض

### المواعيد
- `GET /api/appointments` - قائمة المواعيد
- `POST /api/appointments` - حجز موعد جديد
- `PUT /api/appointments/:id` - تحديث موعد

### التحاليل
- `GET /api/tests` - قائمة التحاليل
- `POST /api/tests` - إضافة تحليل جديد
- `GET /api/test-results` - نتائج التحاليل

### الاستشارات
- `GET /api/consultations` - قائمة الاستشارات
- `POST /api/consultations` - إنشاء استشارة جديدة

## الدردشة المباشرة

النظام يدعم الدردشة المباشرة بين المرضى والأدمن باستخدام Socket.IO:

- **للمرضى:** زر عائم في أسفل يسار الشاشة
- **للأدمن:** قسم الاستشارات في لوحة التحكم
- **المميزات:** رسائل فورية، إشعارات، تاريخ الرسائل

## المساهمة

1. Fork المشروع
2. أنشئ branch جديد (`git checkout -b feature/AmazingFeature`)
3. Commit التغييرات (`git commit -m 'Add some AmazingFeature'`)
4. Push إلى Branch (`git push origin feature/AmazingFeature`)
5. افتح Pull Request

## الترخيص

هذا المشروع مرخص تحت رخصة MIT - انظر ملف [LICENSE](LICENSE) للتفاصيل.

## الدعم

إذا واجهت أي مشاكل أو لديك أسئلة، يرجى فتح issue في GitHub أو التواصل معنا.

---

**تم تطوير هذا النظام بواسطة فريق معمل أمان للتحاليل الطبية** 