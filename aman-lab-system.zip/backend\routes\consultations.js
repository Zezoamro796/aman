const express = require('express');
const router = express.Router();
const Consultation = require('../models/Consultation');
const User = require('../models/User');
const jwt = require('jsonwebtoken');

// Middleware للتحقق من الـ token
const authenticateToken = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    
    if (!token) {
      return res.status(401).json({ message: 'Token مطلوب' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback_secret');
    const user = await User.findById(decoded.userId);
    
    if (!user) {
      return res.status(404).json({ message: 'المستخدم غير موجود' });
    }

    req.user = user;
    next();
  } catch (error) {
    res.status(401).json({ message: 'Token غير صالح' });
  }
};

// إنشاء استشارة جديدة (دردشة)
router.post('/consultations', authenticateToken, async (req, res) => {
  try {
    const { subject, message, priority, category } = req.body;
    const patientId = req.user._id;
    if (!subject || !message) {
      return res.status(400).json({ message: 'يرجى ملء الحقول المطلوبة' });
    }
    const consultation = new Consultation({
      patientId,
      subject,
      messages: [{ sender: 'patient', text: message, timestamp: new Date() }],
      priority: priority || 'medium',
      category: category || 'general'
    });
    await consultation.save();
    res.status(201).json({ message: 'تم بدء الدردشة بنجاح', consultation });
  } catch (error) {
    console.error('Create consultation error:', error);
    res.status(500).json({ message: 'حدث خطأ أثناء إرسال الاستشارة' });
  }
});

// جلب كل الاستشارات (مع الرسائل)
router.get('/consultations', authenticateToken, async (req, res) => {
  try {
    const { patientId, status, priority } = req.query;
    let filter = {};
    if (req.user.role === 'patient') {
      filter.patientId = req.user._id;
    } else if (patientId) {
      filter.patientId = patientId;
    }
    if (status) filter.status = status;
    if (priority) filter.priority = priority;
    const consultations = await Consultation.find(filter)
      .populate('patientId', 'name phone email')
      .sort({ createdAt: -1 });
    res.json(consultations);
  } catch (error) {
    console.error('Get consultations error:', error);
    res.status(500).json({ message: 'حدث خطأ أثناء جلب الاستشارات' });
  }
});

// جلب استشارة واحدة
router.get('/consultations/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const consultation = await Consultation.findById(id)
      .populate('patientId', 'name phone email');
    
    if (!consultation) {
      return res.status(404).json({ message: 'الاستشارة غير موجودة' });
    }

    // التحقق من الصلاحيات
    if (req.user.role !== 'admin' && consultation.patientId._id.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'غير مصرح لك بالوصول لهذه الاستشارة' });
    }

    res.json(consultation);
  } catch (error) {
    console.error('Get consultation error:', error);
    res.status(500).json({ message: 'حدث خطأ أثناء جلب الاستشارة' });
  }
});

// إرسال رسالة جديدة في الدردشة
router.post('/consultations/:id/message', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { text } = req.body;
    if (!text) return res.status(400).json({ message: 'يرجى كتابة الرسالة' });
    const consultation = await Consultation.findById(id);
    if (!consultation) return res.status(404).json({ message: 'الاستشارة غير موجودة' });
    // فقط المريض أو الأدمن يمكنهم إرسال الرسائل
    if (
      req.user.role !== 'admin' &&
      consultation.patientId.toString() !== req.user._id.toString()
    ) {
      return res.status(403).json({ message: 'غير مصرح لك بإرسال الرسائل في هذه الدردشة' });
    }
    const sender = req.user.role === 'admin' ? 'admin' : 'patient';
    consultation.messages.push({ sender, text, timestamp: new Date() });
    await consultation.save();
    res.json({ message: 'تم إرسال الرسالة', consultation });
  } catch (error) {
    console.error('Send chat message error:', error);
    res.status(500).json({ message: 'حدث خطأ أثناء إرسال الرسالة' });
  }
});

// تحديث حالة الاستشارة
router.patch('/consultations/:id/status', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const consultation = await Consultation.findById(id);
    if (!consultation) {
      return res.status(404).json({ 
        message: 'الاستشارة غير موجودة' 
      });
    }

    // التحقق من الصلاحيات
    if (req.user.role !== 'admin' && consultation.patientId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ 
        message: 'غير مصرح لك بتحديث هذه الاستشارة' 
      });
    }

    consultation.status = status;
    await consultation.save();

    res.json({
      message: 'تم تحديث حالة الاستشارة بنجاح',
      consultation
    });

  } catch (error) {
    console.error('Update consultation status error:', error);
    res.status(500).json({ 
      message: 'حدث خطأ أثناء تحديث حالة الاستشارة' 
    });
  }
});

// حذف استشارة
router.delete('/consultations/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const consultation = await Consultation.findById(id);

    if (!consultation) {
      return res.status(404).json({ 
        message: 'الاستشارة غير موجودة' 
      });
    }

    // التحقق من الصلاحيات
    if (req.user.role !== 'admin' && consultation.patientId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ 
        message: 'غير مصرح لك بحذف هذه الاستشارة' 
      });
    }

    await Consultation.findByIdAndDelete(id);

    res.json({ 
      message: 'تم حذف الاستشارة بنجاح' 
    });

  } catch (error) {
    console.error('Delete consultation error:', error);
    res.status(500).json({ 
      message: 'حدث خطأ أثناء حذف الاستشارة' 
    });
  }
});

// الحصول على إحصائيات الاستشارات (للمدير)
router.get('/consultations/stats', authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ 
        message: 'غير مصرح لك بالوصول للإحصائيات' 
      });
    }

    const stats = await Consultation.aggregate([
      {
        $facet: {
          total: [{ $count: 'count' }],
          byStatus: [
            { $group: { _id: '$status', count: { $sum: 1 } } }
          ],
          byPriority: [
            { $group: { _id: '$priority', count: { $sum: 1 } } }
          ],
          pending: [
            { $match: { status: 'pending' } },
            { $count: 'count' }
          ]
        }
      }
    ]);

    res.json({
      total: stats[0].total[0]?.count || 0,
      byStatus: stats[0].byStatus,
      byPriority: stats[0].byPriority,
      pending: stats[0].pending[0]?.count || 0
    });

  } catch (error) {
    console.error('Get consultation stats error:', error);
    res.status(500).json({ 
      message: 'حدث خطأ أثناء جلب إحصائيات الاستشارات' 
    });
  }
});

module.exports = router; 