const express = require('express');
const router = express.Router();
const Inventory = require('../models/Inventory');

// Get all inventory items
router.get('/inventory', async (req, res) => {
  try {
    const items = await Inventory.find();
    res.json(items);
  } catch (err) {
    res.status(500).json({ message: 'خطأ في جلب بيانات المخزون', error: err.message });
  }
});

// Add new inventory item
router.post('/inventory', async (req, res) => {
  try {
    const item = new Inventory(req.body);
    await item.save();
    res.status(201).json({ message: 'تمت إضافة المادة بنجاح', item });
  } catch (err) {
    res.status(400).json({ message: 'خطأ في إضافة المادة', error: err.message });
  }
});

// Update inventory item
router.put('/inventory/:id', async (req, res) => {
  try {
    const item = await Inventory.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!item) return res.status(404).json({ message: 'المادة غير موجودة' });
    res.json({ message: 'تم تحديث المادة بنجاح', item });
  } catch (err) {
    res.status(400).json({ message: 'خطأ في تحديث المادة', error: err.message });
  }
});

// Delete inventory item
router.delete('/inventory/:id', async (req, res) => {
  try {
    const item = await Inventory.findByIdAndDelete(req.params.id);
    if (!item) return res.status(404).json({ message: 'المادة غير موجودة' });
    res.json({ message: 'تم حذف المادة بنجاح' });
  } catch (err) {
    res.status(400).json({ message: 'خطأ في حذف المادة', error: err.message });
  }
});

// Get expired inventory items
router.get('/inventory/expired', async (req, res) => {
  try {
    const now = new Date();
    const expired = await Inventory.find({ expiryDate: { $lt: now } });
    res.json(expired);
  } catch (err) {
    res.status(500).json({ message: 'خطأ في جلب المواد المنتهية', error: err.message });
  }
});

module.exports = router; 