const mongoose = require('mongoose');

const consultationSchema = new mongoose.Schema({
  patientId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  subject: {
    type: String,
    required: true,
    trim: true
  },
  messages: [
    {
      sender: { type: String, enum: ['patient', 'admin'], required: true },
      text: { type: String, required: true },
      timestamp: { type: Date, default: Date.now }
    }
  ],
  status: {
    type: String,
    enum: ['open', 'closed'],
    default: 'open'
  },
  priority: {
    type: String,
    enum: ['low', 'medium', 'high'],
    default: 'medium'
  },
  category: {
    type: String,
    enum: ['general', 'urgent', 'followup'],
    default: 'general'
  }
}, {
  timestamps: true
});

// إنشاء فهارس للبحث السريع
consultationSchema.index({ patientId: 1, createdAt: -1 });
consultationSchema.index({ status: 1 });
consultationSchema.index({ priority: 1 });

module.exports = mongoose.model('Consultation', consultationSchema); 