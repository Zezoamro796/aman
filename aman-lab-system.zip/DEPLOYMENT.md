# تعليمات رفع الموقع على الإنترنت

## الطريقة السريعة (موصى بها)

### 1. رفع على Render (Backend + Frontend معاً)

1. **اذهب إلى [render.com](https://render.com)**
2. **سجل حساب جديد**
3. **اختر "New Web Service"**
4. **ارفع مجلد المشروع كاملاً (New folder)**
5. **Render سيكتشف ملف `render.yaml` تلقائياً**
6. **انتظر 5-10 دقائق حتى يتم الرفع**

### 2. الروابط النهائية

بعد الرفع، ستجد:
- **Backend:** `https://aman-lab-backend.onrender.com`
- **Frontend:** `https://aman-lab-frontend.onrender.com`

## الطريقة البديلة (رفع منفصل)

### رفع Backend على Render:

1. اذهب إلى [render.com](https://render.com)
2. اختر "New Web Service"
3. ارفع مجلد `backend` فقط
4. اختر Node.js كـ Runtime
5. اكتب `npm start` كـ Start Command
6. أضف متغيرات البيئة:
   ```
   MONGO_URI=mongodb+srv://amanlab:amanlab123@cluster0.mongodb.net/aman_lab?retryWrites=true&w=majority
   JWT_SECRET=aman_lab_secret_key_2024
   NODE_ENV=production
   ```

### رفع Frontend على Netlify:

1. اذهب إلى [netlify.com](https://netlify.com)
2. اسحب مجلد المشروع الرئيسي (index.html)
3. سيتم رفع الموقع فوراً

## تحديث الروابط في الكود

بعد الحصول على رابط Backend، قم بتحديث الروابط في `index.html`:

```javascript
// في السطر 2270 تقريباً
const apiBase = window.location.hostname === 'localhost' || 
               window.location.hostname === '127.0.0.1' ||
               window.location.hostname === ''
    ? 'http://localhost:3000/api'
    : 'https://YOUR_BACKEND_URL.onrender.com/api';

// في السطر 2280 تقريباً
const socketUrl = window.location.hostname === 'localhost' || 
                 window.location.hostname === '127.0.0.1' ||
                 window.location.hostname === ''
    ? 'http://localhost:3000'
    : 'https://YOUR_BACKEND_URL.onrender.com';
```

## ملاحظات مهمة

- **MongoDB Atlas:** تم إعداد قاعدة البيانات على MongoDB Atlas
- **CORS:** تم إعداد CORS للعمل مع Render
- **Environment Variables:** تم إعدادها في ملف `render.yaml`
- **Port:** سيتم تعيينه تلقائياً بواسطة Render

## اختبار الموقع

بعد الرفع:
1. افتح رابط Frontend
2. جرب تسجيل الدخول
3. اختبر جميع الميزات
4. تأكد من عمل الدردشة

## الدعم

إذا واجهت أي مشاكل:
1. تحقق من logs في Render
2. تأكد من صحة متغيرات البيئة
3. تحقق من اتصال MongoDB Atlas 