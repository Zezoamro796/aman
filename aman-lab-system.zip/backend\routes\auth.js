const express = require('express');
const router = express.Router();
const User = require('../models/User');
const jwt = require('jsonwebtoken');

// تسجيل مستخدم جديد
router.post('/register', async (req, res) => {
  console.log('Register request body:', req.body);
  try {
    const { name, phone, email, password } = req.body;

    // التحقق من وجود المستخدم
    const existingUser = await User.findOne({ 
      $or: [{ phone }, { email: email || '' }] 
    });
    
    if (existingUser) {
      return res.status(400).json({ 
        message: 'رقم الهاتف أو البريد الإلكتروني مستخدم بالفعل' 
      });
    }

    // إنشاء مستخدم جديد
    const user = new User({
      name,
      phone,
      email,
      password,
      role: 'patient'
    });

    await user.save();

    // إنشاء token
    const token = jwt.sign(
      { userId: user._id, role: user.role },
      process.env.JWT_SECRET || 'fallback_secret',
      { expiresIn: '7d' }
    );

    res.status(201).json({
      message: 'تم إنشاء الحساب بنجاح',
      user: {
        _id: user._id,
        name: user.name,
        phone: user.phone,
        email: user.email,
        role: user.role
      },
      token
    });

  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ 
      message: 'حدث خطأ أثناء إنشاء الحساب' 
    });
  }
});

// تسجيل الدخول
router.post('/login', async (req, res) => {
  console.log('Login request body:', req.body);
  try {
    const { phoneOrEmail, password } = req.body;

    // البحث عن المستخدم
    const user = await User.findOne({
      $or: [
        { phone: phoneOrEmail },
        { email: phoneOrEmail }
      ]
    });

    if (!user) {
      return res.status(401).json({ 
        message: 'بيانات الدخول غير صحيحة' 
      });
    }

    // التحقق من كلمة المرور
    const isPasswordValid = await user.comparePassword(password);
    if (!isPasswordValid) {
      return res.status(401).json({ 
        message: 'بيانات الدخول غير صحيحة' 
      });
    }

    // إنشاء token
    const token = jwt.sign(
      { userId: user._id, role: user.role },
      process.env.JWT_SECRET || 'fallback_secret',
      { expiresIn: '7d' }
    );

    res.json({
      message: 'تم تسجيل الدخول بنجاح',
      user: {
        _id: user._id,
        name: user.name,
        phone: user.phone,
        email: user.email,
        role: user.role
      },
      token,
      isAdmin: user.role === 'admin'
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ 
      message: 'حدث خطأ أثناء تسجيل الدخول' 
    });
  }
});

// التحقق من وجود رقم الهاتف قبل التسجيل
router.post('/users/check-phone', async (req, res) => {
  try {
    const { phone } = req.body;
    if (!phone) return res.status(400).json({ message: 'رقم الهاتف مطلوب' });
    const user = await User.findOne({ phone });
    res.json({ exists: !!user });
  } catch (error) {
    res.status(500).json({ message: 'حدث خطأ أثناء التحقق من رقم الهاتف' });
  }
});

// الحصول على معلومات المستخدم
router.get('/profile', async (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    
    if (!token) {
      return res.status(401).json({ message: 'Token مطلوب' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback_secret');
    const user = await User.findById(decoded.userId).select('-password');
    
    if (!user) {
      return res.status(404).json({ message: 'المستخدم غير موجود' });
    }

    res.json({ user });

  } catch (error) {
    console.error('Profile error:', error);
    res.status(401).json({ message: 'Token غير صالح' });
  }
});

module.exports = router; 