const express = require('express');
const router = express.Router();
const Appointment = require('../models/Appointment');
const User = require('../models/User');
const jwt = require('jsonwebtoken');

// Middleware للتحقق من الـ token
const authenticateToken = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    
    if (!token) {
      return res.status(401).json({ message: 'Token مطلوب' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback_secret');
    const user = await User.findById(decoded.userId);
    
    if (!user) {
      return res.status(404).json({ message: 'المستخدم غير موجود' });
    }

    req.user = user;
    next();
  } catch (error) {
    res.status(401).json({ message: 'Token غير صالح' });
  }
};

// إنشاء موعد جديد
router.post('/appointments', authenticateToken, async (req, res) => {
  try {
    const { type, date, time, notes } = req.body;
    const patientId = req.user._id;

    // التحقق من البيانات
    if (!type || !date || !time) {
      return res.status(400).json({ 
        message: 'يرجى ملء جميع الحقول المطلوبة' 
      });
    }

    // التحقق من أن التاريخ في المستقبل
    const appointmentDate = new Date(date);
    if (appointmentDate < new Date()) {
      return res.status(400).json({ 
        message: 'لا يمكن حجز موعد في الماضي' 
      });
    }

    // إنشاء الموعد
    const appointment = new Appointment({
      patientId,
      type,
      date: appointmentDate,
      time,
      notes,
      status: 'جديد'
    });

    await appointment.save();

    res.status(201).json({
      message: 'تم حجز الموعد بنجاح',
      appointment
    });

  } catch (error) {
    console.error('Create appointment error:', error);
    res.status(500).json({ 
      message: 'حدث خطأ أثناء حجز الموعد' 
    });
  }
});

// الحصول على مواعيد المريض
router.get('/appointments', authenticateToken, async (req, res) => {
  try {
    const { patientId, status, date, search } = req.query;
    let filter = {};

    // إذا كان المستخدم مريض، يمكنه رؤية مواعيده فقط
    if (req.user.role === 'patient') {
      filter.patientId = req.user._id;
    } else if (patientId) {
      filter.patientId = patientId;
    }

    // فلترة حسب الحالة
    if (status) {
      filter.status = status;
    }

    // فلترة حسب التاريخ
    if (date) {
      const startDate = new Date(date);
      const endDate = new Date(date);
      endDate.setDate(endDate.getDate() + 1);
      filter.date = { $gte: startDate, $lt: endDate };
    }

    // دعم البحث بالاسم أو الهاتف أو نوع التحليل أو الملاحظات
    let appointments = await Appointment.find(filter)
      .populate('patientId', 'name phone email')
      .sort({ date: 1, time: 1 });

    if (search) {
      const searchLower = search.toLowerCase();
      appointments = appointments.filter(app => {
        const patient = app.patientId || {};
        return (
          (patient.name && patient.name.toLowerCase().includes(searchLower)) ||
          (patient.phone && patient.phone.includes(searchLower)) ||
          (app.type && app.type.toLowerCase().includes(searchLower)) ||
          (app.notes && app.notes.toLowerCase().includes(searchLower))
        );
      });
    }

    res.json(appointments);

  } catch (error) {
    console.error('Get appointments error:', error);
    res.status(500).json({ 
      message: 'حدث خطأ أثناء جلب المواعيد' 
    });
  }
});

// تحديث حالة الموعد (للمدير)
router.patch('/appointments/:id/status', authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ 
        message: 'غير مصرح لك بتحديث حالة الموعد' 
      });
    }

    const { status } = req.body;
    const { id } = req.params;

    const appointment = await Appointment.findById(id);
    if (!appointment) {
      return res.status(404).json({ 
        message: 'الموعد غير موجود' 
      });
    }

    appointment.status = status;
    await appointment.save();

    res.json({
      message: 'تم تحديث حالة الموعد بنجاح',
      appointment
    });

  } catch (error) {
    console.error('Update appointment status error:', error);
    res.status(500).json({ 
      message: 'حدث خطأ أثناء تحديث حالة الموعد' 
    });
  }
});

// حذف موعد
router.delete('/appointments/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const appointment = await Appointment.findById(id);

    if (!appointment) {
      return res.status(404).json({ 
        message: 'الموعد غير موجود' 
      });
    }

    // التحقق من الصلاحيات
    if (req.user.role !== 'admin' && appointment.patientId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ 
        message: 'غير مصرح لك بحذف هذا الموعد' 
      });
    }

    await Appointment.findByIdAndDelete(id);

    res.json({ 
      message: 'تم حذف الموعد بنجاح' 
    });

  } catch (error) {
    console.error('Delete appointment error:', error);
    res.status(500).json({ 
      message: 'حدث خطأ أثناء حذف الموعد' 
    });
  }
});

// الحصول على إحصائيات المواعيد (للمدير)
router.get('/appointments/stats', authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ 
        message: 'غير مصرح لك بالوصول للإحصائيات' 
      });
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const stats = await Appointment.aggregate([
      {
        $facet: {
          total: [{ $count: 'count' }],
          today: [
            { $match: { date: { $gte: today, $lt: tomorrow } } },
            { $count: 'count' }
          ],
          byStatus: [
            { $group: { _id: '$status', count: { $sum: 1 } } }
          ]
        }
      }
    ]);

    res.json({
      total: stats[0].total[0]?.count || 0,
      today: stats[0].today[0]?.count || 0,
      byStatus: stats[0].byStatus
    });

  } catch (error) {
    console.error('Get stats error:', error);
    res.status(500).json({ 
      message: 'حدث خطأ أثناء جلب الإحصائيات' 
    });
  }
});

module.exports = router; 